<?php

namespace App\Traits;

trait ResponseTrait
{
    public function sendResponse($result, $message, $code = 200)
    {
        $response = [
            'success' => true,
            'message' => $message,
        ];

        // Handle paginated results
        if ($result instanceof \Illuminate\Pagination\LengthAwarePaginator) {
            $response['data'] = $result->items();
            $response['pagination'] = [
                'total' => $result->total(),
                'per_page' => $result->perPage(),
                'current_page' => $result->currentPage(),
                'last_page' => $result->lastPage(),
                'from' => $result->firstItem(),
                'to' => $result->lastItem(),
                'next_page_url' => $result->nextPageUrl(),
                'prev_page_url' => $result->previousPageUrl(),
            ];
        } else {
            $response['data'] = $result;
        }

        return response()->json($response, $code);
    }


    public function sendError($error, $customMessage = null, $statusCode = 400, $additionalData = null)
    {
        $response = [
            'success' => false,
            'message' => $customMessage ?? 'An error occurred',
        ];

        // Handle different error types
        if ($error instanceof \Illuminate\Validation\Validator) {
            // Validation errors
            $response['errors'] = $error->errors()->toArray();
            $statusCode = 422;
            $response['message'] = $customMessage ?? 'Validation failed';
        } elseif ($error instanceof \Illuminate\Validation\ValidationException) {
            // Validation exception
            $response['errors'] = $error->errors();
            $statusCode = 422;
            $response['message'] = $customMessage ?? 'Validation failed';
        } elseif ($error instanceof \Illuminate\Database\Eloquent\ModelNotFoundException) {
            // Model not found
            $statusCode = 404;
            $response['message'] = $customMessage ?? 'Resource not found';
        } elseif ($error instanceof \Illuminate\Database\QueryException) {
            // Database query errors
            $statusCode = 500;
            $response['message'] = $customMessage ?? 'Database error occurred';
            if (config('app.debug')) {
                $response['debug'] = [
                    'sql' => $error->getSql(),
                    'bindings' => $error->getBindings(),
                ];
            }
        } elseif ($error instanceof \Illuminate\Auth\AuthenticationException) {
            // Authentication errors
            $statusCode = 401;
            $response['message'] = $customMessage ?? 'Unauthenticated';
        } elseif ($error instanceof \Illuminate\Auth\Access\AuthorizationException) {
            // Authorization errors
            $statusCode = 403;
            $response['message'] = $customMessage ?? 'Unauthorized';
        } elseif ($error instanceof \Symfony\Component\HttpKernel\Exception\NotFoundHttpException) {
            // Route not found
            $statusCode = 404;
            $response['message'] = $customMessage ?? 'Endpoint not found';
        } elseif ($error instanceof \Symfony\Component\HttpKernel\Exception\MethodNotAllowedHttpException) {
            // Method not allowed
            $statusCode = 405;
            $response['message'] = $customMessage ?? 'Method not allowed';
        } elseif ($error instanceof \Illuminate\Http\Exceptions\ThrottleRequestsException) {
            // Rate limiting
            $statusCode = 429;
            $response['message'] = $customMessage ?? 'Too many requests';
        } elseif ($error instanceof \Exception) {
            // Generic exceptions
            $statusCode = method_exists($error, 'getStatusCode')
                ? $error->getStatusCode()
                : 500;
            $response['message'] = $customMessage ?? $error->getMessage();

            if (config('app.debug')) {
                $response['debug'] = [
                    'exception' => get_class($error),
                    'file' => $error->getFile(),
                    'line' => $error->getLine(),
                    'trace' => $error->getTrace(),
                ];
            }
        } elseif (is_array($error)) {
            // Array of errors
            $response['errors'] = $error;
        } elseif (is_string($error)) {
            // Simple error message
            $response['message'] = $error;
        }

        // Add additional data if provided
        if ($additionalData !== null) {
            $response['data'] = $additionalData;
        }

        return response()->json($response, $statusCode);
    }
}
