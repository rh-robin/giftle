<?php

namespace App\Http\Controllers\API\Auth;

use Exception;
use App\Models\User;
use Illuminate\Http\Request;
use App\Traits\ResponseTrait;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Hash;

class LoginController extends Controller
{
    use ResponseTrait;

    /**
     * Handles user login using their email and password.
     *
     * @param Request $request
     * @return \Illuminate\Http\JsonResponse
     */
    public function login(Request $request): \Illuminate\Http\JsonResponse
    {
        $request->validate([
            'email'    => 'required|string',
            'password' => 'required|string',
        ]);

        try {
            // Check if the user exists
            $user = User::withTrashed()->where('email', $request->email)->first();

            if (empty($user)) {
                return $this->sendError('User not found. Please check your email or register for an account.',);
            }

            // Check the password
            if (!Hash::check($request->password, $user->password)) {
                return $this->sendError( 'Incorrect password. Please try again or reset your password if you\'ve forgotten it.',);
            }

            // Generate token if email is verified
            if (!$user->hasVerifiedEmail()) {
                return $this->sendError('Email not verified. Please verify your email before logging in.');
            }

            $token = $user->createToken('Login Token')->plainTextToken;

            return $this->sendResponse(
                'User logged in successfully',
                [
                    'token' => $token,
                    'user'  => $user
                ]
            );
        } catch (Exception $e) {
            return $this->sendError('Something went wrong. Please try again later.', 500);
        }
    }

    public function refreshToken(): \Illuminate\Http\JsonResponse
    {
        try {
            $refreshToken = auth('api')->refresh();

            return $this->sendResponse('Token refreshed successfully', ['token' => $refreshToken]);
        } catch (Exception $e) {
            return $this->sendError('Something went wrong');
        }
    }
}
